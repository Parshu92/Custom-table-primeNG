export interface DTableColumn{
    name:any;
    dataKey:string;
    position:string;
    isSortable?:boolean;
    format?:string;
}