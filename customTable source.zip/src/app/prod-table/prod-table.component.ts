import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { DTableColumn } from './grid-columns';

@Component({
  selector: 'app-prod-table',
  templateUrl: './prod-table.component.html',
  styleUrls: ['./prod-table.component.css']
})
export class ProdTableComponent implements OnInit {

  @Input() isPageable = false;
  @Input() tableColumns:Array<DTableColumn> = [];
  @Input() tableData:any;
  @Input() paginationSizes:number[]=[5,10,15];
  @Input() defaultPageSize = this.paginationSizes[1];


  @Output() rowAction: EventEmitter<any> = new EventEmitter();
  @Output() rowSecondaryAction: EventEmitter<any> = new EventEmitter();

  ngOnInit(): void {
  }

  emitRowAction(row:any){
    this.rowAction.emit(row);
  }

  emitSecodaryRowAction(row:any){
    this.rowSecondaryAction.emit(row);
  }


}
