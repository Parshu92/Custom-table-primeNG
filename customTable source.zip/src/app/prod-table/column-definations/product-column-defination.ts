export const ProductColumnDefination = [
    {
    "name":"ID",
    "longName":"Product ID",
    "dataKey":"id",
    "position":"left",
    "isSortble":false,
    "format":"",
},
{
    "name":"Book",
    "longName":"Book",
    "dataKey":"book",
    "position":"left",
    "isSortble":false,
    "format":"",
},
{
    "name":"Author",
    "longName":"Author Name",
    "dataKey":"author",
    "position":"left",
    "isSortble":false,
    "format":"",
},
{
    "name":"Published Date",
    "longName":"Publication Date",
    "dataKey":"datepublished",
    "position":"left",
    "isSortble":false,
    "format":"date",
},
{
    "name":"No Of Subscribe",
    "longName":"Number Of Subscribe",
    "dataKey":"no_of_subscribe",
    "position":"left",
    "isSortble":false,
    "format":"number",
},
{
    "name":"No Of Unsubscribe",
    "longName":"Number Of Unsubscribe",
    "dataKey":"no_of_unsubscribe",
    "position":"left",
    "isSortble":false,
    "format":"number",
}   

]