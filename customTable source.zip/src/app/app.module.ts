import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProdTableComponent } from './prod-table/prod-table.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TableModule } from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {PaginatorModule} from 'primeng/paginator';
import { DataPropertyGetterPipe } from './prod-table/pipe/data-property-getter.pipe';
import { FetchJsonDataService } from './services/fetch-json-data.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    ProdTableComponent,
    DataPropertyGetterPipe
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    AppRoutingModule,
    TableModule,
    ButtonModule,
    PaginatorModule,
    
  ],
  providers: [FetchJsonDataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
