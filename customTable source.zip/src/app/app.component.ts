import { Component } from '@angular/core';
import { ProductColumnDefination } from './prod-table/column-definations/product-column-defination';
import { DTableColumn } from './prod-table/grid-columns';
import { FetchJsonDataService } from './services/fetch-json-data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'CustomTable';
  tableData:any;
  tableColumnss!:Array<DTableColumn>;
  constructor(private fetchJsonDataService:FetchJsonDataService){
  this.tableColumnss = ProductColumnDefination;
  }
  ngOnInit(){
    this.getBookData();
  }
   
  getBookData(){
    this.fetchJsonDataService.getData().subscribe(res =>{  
      this.tableData = res;
    });
  }

  subscribe($event:any){
    const newArr = this.tableData.map((ele:any) =>{
      if (ele.id == $event.id) {
        return { ...ele , no_of_subscribe : ele.no_of_subscribe+1}
      }
      return ele;
     });
     this.tableData = newArr;
    }

  unsubscribe($event:any){
   const newArr = this.tableData.map((ele:any) =>{
    if (ele.id == $event.id) {
      return { ...ele , no_of_unsubscribe : ele.no_of_unsubscribe+1}
    }
    return ele;
   });
   this.tableData = newArr;
  }
}
